import torch
import torch.nn as nn
import torch.nn.functional as F

# -----Nonlacal------------------------------------------------------------------------------------------------#

class NonLocalBlock(nn.Module):
    def __init__(self, dim_in, dim_out, dim_inner):
        super(NonLocalBlock, self).__init__()

        self.dim_in = dim_in
        self.dim_inner = dim_inner
        self.dim_out = dim_out

        self.theta = nn.Conv3d(dim_in, dim_inner, kernel_size=(1, 1, 1), stride=(1, 1, 1), padding=(0, 0, 0))
        self.phi = nn.Conv3d(dim_in, dim_inner, kernel_size=(1, 1, 1), stride=(1, 1, 1), padding=(0, 0, 0))
        self.g = nn.Conv3d(dim_in, dim_inner, kernel_size=(1, 1, 1), stride=(1, 1, 1), padding=(0, 0, 0))

        self.out = nn.Conv3d(dim_inner, dim_out, kernel_size=(1, 1, 1), stride=(1, 1, 1), padding=(0, 0, 0))
        self.bn = nn.BatchNorm3d(dim_out)

    def forward(self, x):
        residual = x

        batch_size = x.shape[0]
        mp = x
        theta = self.theta(x)
        phi = self.phi(mp)
        g = self.g(mp)

        theta_shape_5d = theta.shape
        theta, phi, g = theta.view(batch_size, self.dim_inner, -1), phi.view(batch_size, self.dim_inner, -1), g.view(
            batch_size, self.dim_inner, -1)

        theta_phi = torch.bmm(theta.transpose(1, 2), phi)  # (8, 1024, 784) * (8, 1024, 784) => (8, 784, 784)
        theta_phi_sc = theta_phi * (self.dim_inner ** -.5)
        p = F.softmax(theta_phi_sc, dim=-1)

        t = torch.bmm(g, p.transpose(1, 2))
        t = t.view(theta_shape_5d)

        out = self.out(t)
        out = self.bn(out)

        out = out + residual
        return out


# -------CC_net----------------------------------------------------------------------------------------#



def INF3DH(B, H, W, D):
    return -torch.diag(torch.tensor(float("inf")).repeat(H), 0).unsqueeze(0).repeat(B * W * D, 1, 1)  # .cuda()


def INF3DW(B, H, W, D):
    return -torch.diag(torch.tensor(float("inf")).repeat(W), 0).unsqueeze(0).repeat(B * H * D, 1, 1)  # .cuda()


def INF3DD(B, H, W, D):
    return -torch.diag(torch.tensor(float("inf")).repeat(D), 0).unsqueeze(0).repeat(B * H * W, 1, 1)  # .cuda()


class CrissCrossAttention3D(nn.Module):
    """ Criss-Cross Attention Module 3D version, inspired by the 2d version, but 3D CC Module should mask out the overlapped elements twice!"""

    def __init__(self, in_dim, verbose=False):
        super(CrissCrossAttention3D, self).__init__()
        self.query_conv = nn.Conv3d(in_channels=in_dim, out_channels=in_dim // 8, kernel_size=1)
        self.key_conv = nn.Conv3d(in_channels=in_dim, out_channels=in_dim // 8, kernel_size=1)
        self.value_conv = nn.Conv3d(in_channels=in_dim, out_channels=in_dim, kernel_size=1)
        self.softmax = nn.Softmax(dim=4)
        self.gamma = nn.Parameter(torch.zeros(1))
        self.verbose = verbose
        self.INFH = INF3DH
        self.INFD = INF3DD

    def energy(self, x, query, key):
        m_batchsize, _, height, width, depth = x.size()
        # (B,C/8,H,W,T)
        # (B,C/8,H,W,T) -> (B,W,T,C/8,H) -> (B*W*T,C/8,H) -> (B*W*T,H,C/8)
        # bchw > bwch, b*w*d-c-h > b*w*d-h-c
        query_H = query.permute(0, 3, 4, 1, 2).contiguous().view(m_batchsize * width * depth, -1, height).permute(0, 2, 1)
        # bchw > bhcw, b*h*d-c-w > b*h*d-w-c
        query_W = query.permute(0, 2, 4, 1, 3).contiguous().view(m_batchsize * height * depth, -1, width).permute(0, 2,
                                                                                                                  1)
        # bchwd > bwch, b*h*w-c-d > b*h*w-d-c
        query_D = query.permute(0, 2, 3, 1, 4).contiguous().view(m_batchsize * height * width, -1, depth).permute(0, 2,
                                                                                                                  1)

        # bchw > bwch, b*w*d-c-h
        key_H = key.permute(0, 3, 4, 1, 2).contiguous().view(m_batchsize * width * depth, -1, height)
        # bchw > bhcw, b*h*d-c-w
        key_W = key.permute(0, 2, 4, 1, 3).contiguous().view(m_batchsize * height * depth, -1, width)
        key_D = key.permute(0, 2, 3, 1, 4).contiguous().view(m_batchsize * height * width, -1, depth)  # b*h*w-c-d

        # batch matrix-matrix
        inf_holder = self.INFH(m_batchsize, height, width, depth).to(x.device)  # > bw-h-h

        energy_H = torch.bmm(query_H, key_H) + inf_holder  # bwd-h-c, bwd-c-h > bwd-h-h
        energy_H = energy_H.view(m_batchsize, width, depth, height, height).permute(0, 1, 3, 2, 4)  # bwhdh

        #  b*h*d-w-c, b*h*d-c-w > b*h*d-w-w
        energy_W = torch.bmm(query_W, key_W)  # +self.INFW(m_batchsize, height, width, depth)
        energy_W = energy_W.view(m_batchsize, height, depth, width, width).permute(0, 3, 1, 2, 4)  # bwhdw
        #  b*h*w-d-c, b*h*w-c-d > b*h*w-d-d
        energy_D = (torch.bmm(query_D, key_D) + self.INFD(m_batchsize, height, width, depth).to(x.device)).view(
            m_batchsize, height, width, depth, depth).permute(0, 2, 1, 3, 4)  # bwhdd
        return energy_H, energy_W, energy_D

    def forward(self, x):
        # bcdhw -> bchwt
        # (B,C,H,W,T)
        m_batchsize, _, height, width, depth = x.size()
        query = self.query_conv(x)
        key = self.key_conv(x)

        energy_H, energy_W, energy_D = self.energy(x, query, key)
        concate = self.softmax(torch.cat([energy_H, energy_W, energy_D], 4))  # bwhd*(h+w+d)

        # bhw(H+W) > bhwH, bwhH;
        att_H = concate[:, :, :, :, 0:height].permute(0, 1, 3, 2, 4).contiguous().view(m_batchsize * width * depth, height, height)
        att_W = concate[:, :, :, :, height:height + width].permute(0, 2, 3, 1, 4).contiguous().view(m_batchsize * height * depth, width, width)
        att_D = concate[:, :, :, :, height + width:].permute(0, 2, 1, 3, 4).contiguous().view(m_batchsize * height * width, depth, depth)

        value = self.value_conv(x)
        value_H = value.permute(0, 3, 4, 1, 2).contiguous().view(m_batchsize * width * depth, -1,
                                                                 height)  # bchwd->bwdch
        value_W = value.permute(0, 2, 4, 1, 3).contiguous().view(m_batchsize * height * depth, -1,
                                                                 width)  # bchwd->bhdcw
        value_D = value.permute(0, 2, 3, 1, 4).contiguous().view(m_batchsize * height * width, -1,
                                                                 depth)  # bchwd->bhwcd

        # p-c-h, p-h-h > p-c-h
        out_H = torch.bmm(value_H, att_H.permute(0, 2, 1)).view(m_batchsize, width, depth, -1, height).permute(0, 3, 4,
                                                                                                               1, 2)
        out_W = torch.bmm(value_W, att_W.permute(0, 2, 1)).view(m_batchsize, height, depth, -1, width).permute(0, 3, 1,
                                                                                                               4, 2)
        out_D = torch.bmm(value_D, att_D.permute(0, 2, 1)).view(m_batchsize, height, width, -1, depth).permute(0, 3, 1,
                                                                                                               2, 4)

        # print(out_H.size(),out_W.size())
        return self.gamma * (out_H + out_W + out_D) + x


class ST3DCCBlock(nn.Module):
    def __init__(self, in_channels, out_channels, forward_expansion=4):
        super(ST3DCCBlock, self).__init__()
        inter_channels = in_channels // 2
        self.conv_in = nn.Sequential(nn.Conv3d(in_channels, inter_channels, kernel_size=3, padding=1, bias=False),
                                     nn.BatchNorm3d(inter_channels),
                                     nn.ReLU(inplace=False))
        self.cca = CrissCrossAttention3D(inter_channels)
        self.conv_mid = nn.Sequential(nn.Conv3d(inter_channels, inter_channels, kernel_size=3, padding=1, bias=False),
                                      nn.BatchNorm3d(inter_channels),
                                      nn.ReLU(inplace=False))

        self.conv_out = nn.Sequential(
            nn.Conv3d(in_channels + inter_channels, out_channels, kernel_size=1, dilation=1, bias=False),)
            # nn.BatchNorm3d(out_channels),
            # nn.ReLU(inplace=False),
            # nn.Dropout3d(0.5))
            # nn.Conv3d(out_channels, in_channels, kernel_size=1, stride=1, padding=0, bias=True))
        # self.feed_forward = nn.Sequential(nn.Linear(in_channels, in_channels * forward_expansion),
        #                                   nn.ReLU(inplace=False),
        #                                   nn.Linear(in_channels * forward_expansion, out_channels))

    def forward(self, x, recurrence=2):
        # (B,C,T,N,N)
        output = self.conv_in(x)
        # (B,C/4,T,N,N)
        output = output.permute(0, 1, 3, 4, 2)
        # (B,C/4,N,N,T)
        for i in range(recurrence):
            output = self.cca(output)
        # bchwd -> bcdhw
        output = output.permute(0, 1, 4, 2, 3)
        # (B,C/4,T,N,N)
        output = self.conv_mid(output)
        # (B,C/4,T,N,N)
        output = self.conv_out(torch.cat([x, output], 1))
        # (B,C,T,N,N)
        # output = self.feed_forward(output + x)
        return output + x

if __name__ == '__main__':
    q = torch.ones((2,4,12,1,100))
    B,C,T,_,_ = q.shape
    k = torch.ones((2,4,12,100, 100))
    v = k
    heatmap = torch.matmul(q, k.transpose(-1, -2))
    heatmap = heatmap * (100 ** -.5)
    heatmap = F.softmax(heatmap,dim=-1)
    # heatmap = self.dropout(heatmap)
    # s: (B, H * W, H * W)
    v = torch.matmul(heatmap,v)
    print(v)