import torch.nn as nn
from .attention import ST3DCCBlock, NonLocalBlock

# 三维卷积块
class ConvBNRelu(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size, **kwargs):
        super().__init__()
        self.conv = nn.Conv3d(in_channels, out_channels, kernel_size=kernel_size, **kwargs)
        self.bn = nn.BatchNorm3d(out_channels)
        self.relu = nn.ReLU()

    def forward(self, x):
        x = self.conv(x)
        x = self.bn(x)
        x = self.relu(x)
        return x


class Block(nn.Module):
    def __init__(self, in_channels, out_channels, stride=1, att=False):
        super().__init__()
        # 包含卷积、批归一化和ReLU激活，和一个额外的BatchNorm3d
        self.block = nn.Sequential(
            ConvBNRelu(in_channels, out_channels, 3, stride=stride, padding=1),
            # nn.Conv3d(out_channels, out_channels, 3, stride=1, padding=1),
            nn.BatchNorm3d(out_channels),
        )
        self.att = att
        # 调整输入和输出通道数，如果不匹配则使用1x1卷积进行降维
        if in_channels != out_channels or stride != 2:
            self.downsample = nn.Sequential(
                nn.Conv3d(in_channels, out_channels, kernel_size=1, stride=stride),
                nn.BatchNorm3d(out_channels),
            )
        else:
            self.downsample = Identity()
        # self.attention = NonLocalBlock(out_channels, out_channels, out_channels)
        self.attention = ST3DCCBlock(out_channels, out_channels) # 引用了attention.py中的ST3DCCBlock
        self.relu = nn.ReLU()

    def forward(self, x):
        res = self.downsample(x) # 残差分支
        x = self.block(x) # 主分支
        x = self.relu(x + res) # 残差连接+激活
        if self.att:
            x = self.attention(x) # 可选：加注意力机制
        return x

# 恒等映射层，输入直接返回输出
class Identity(nn.Module):
    def __init__(self):
        super().__init__()

    def forward(self, x):
        return x

# 三维特征提取网络
class FeatureNet(nn.Module):
    def __init__(self, in_c=16, mid_c=32):
        super(FeatureNet, self).__init__()
        # 三个残差块
        self.layer1 = self._make_layer(in_c, in_c, 1, 1)
        self.layer2 = self._make_layer(in_c, mid_c, 1, 1)
        self.layer3 = self._make_layer(mid_c, in_c, 1, 1, att=True)
        self.bn = nn.BatchNorm3d(in_c) # 对输出进行批归一化
        self.relu = nn.ReLU() # 激活函数
        self.drop = nn.Dropout(0.5) # 防止过拟合

    # 创建残差块,每一个block是一个带残差结构的3D卷积块
    def _make_layer(self, in_channels, out_channels, n_blocks, stride=1, att=False):
        layer_list = [Block(in_channels, out_channels, stride)]
        for i in range(1, n_blocks):
            layer_list.append(Block(out_channels, out_channels, att=att))
        return nn.Sequential(*layer_list)
    
    # 经过三层残差块和批归一化后，输出特征
    def forward(self, x):
        # N, C, T, H, W
        x = self.layer1(x)
        x = self.layer2(x)
        x = self.layer3(x)
        x = self.bn(x)
        x = self.drop(self.relu(x))
        return x


# -------------------------------------resnet18-----------------------------
class ResNet18(nn.Module):
    def __init__(self, height, width, in_channels=1, scale=2, mode='sim'):
        super(ResNet18, self).__init__()
        self.scale = scale # 缩放因子，控制通道数和空间分辨率
        self.node = height * width
        self.h = (self.node if in_channels == 1 else height) // self.scale
        self.w = (self.node if in_channels == 1 else width) // self.scale
        self.maxpool = nn.MaxPool3d(kernel_size=(3, 3, 3), stride=(2, 1, 1),padding=(0,1,1))
        # 输入预处理，卷积和池化层
        self.stem = nn.Sequential(
            ConvBNRelu(in_channels, 64 // self.scale, kernel_size=5, stride=(2, 1, 1), padding=(2, 2, 2), bias=False),
            nn.MaxPool3d(kernel_size=(3, 3, 3), stride=(2, 1, 1), padding=1),
        )
        # 如果不是sim模式，则添加一个卷积层
        if mode != 'sim':
            self.stem = nn.Sequential(
                ConvBNRelu(in_channels, 64 // self.scale, kernel_size=5, stride=2, padding=2, bias=False),
                nn.MaxPool3d(kernel_size=(3, 3, 3), stride=2, padding=1),
            )
        # 四个残差块，每个块包含多个卷积层
        self.layer1 = self._make_layer(64 // self.scale, 64 // self.scale, 2, 1)
        self.layer2 = self._make_layer(64 // self.scale, 128 // self.scale, 2, 1, att=True)
        self.layer3 = self._make_layer(128 // self.scale, 256 // self.scale, 2, 1, att=True)
        self.layer4 = self._make_layer(256 // self.scale, 512 // self.scale, 2, 1)
        # self.up = nn.Upsample(size=[self.h, self.w], mode="bilinear", align_corners=True)
        # self.pool = nn.AdaptiveAvgPool3d(1)
        # 最后的卷积层，将通道数转换为节点数
        self.transform = nn.Conv2d(512 // self.scale, self.node, kernel_size=1)
        self.relu = nn.ReLU()
        self.drop = nn.Dropout(0.5)

    #  创建残差块
    def _make_layer(self, in_channels, out_channels, n_blocks, stride=1, att=False):
        layer_list = []
        layer_list.append(Block(in_channels, out_channels, stride))
        for i in range(1, n_blocks):
            layer_list.append(Block(out_channels, out_channels, att=att))
        return nn.Sequential(*layer_list)

    def forward(self, x):
        n, c, t, h, w = x.shape
        # x = x.reshape([-1, self.num_seg, c, h, w]).transpose([0, 2, 1, 3, 4])  # N, C, T, H, W
        res = x
        x = self.stem(x)
        x1 = self.layer1(x)
        x1 = self.maxpool(x1)
        x2 = self.layer2(x1)
        x3 = self.layer3(x2)
        x4 = self.layer4(x3)  # N, C, T, H, W
        x5 = self.transform(x4.squeeze())
        x5 = self.drop(self.relu(x5))
        # x = self.fc(x5.reshape([n, self.node, -1]))
        # x = self.pool(x).reshape([x.shape[0], -1])  # N, C
        return x5.reshape([n, self.node, -1])


# --------Resnet50---------------------------------------------------------------------------------------#


class Bottleneck(nn.Module):
    # 定义Bottleneck模块，包含3个卷积层和一个可选的非线性块
    expansion = 4
    def __init__(self, inplanes, planes, stride, downsample, temp_conv, temp_stride, use_nl=False):
        super(Bottleneck, self).__init__()
        # 依次经过三个卷积层，使用BatchNorm3d和ReLU激活
        self.conv1 = nn.Conv3d(inplanes, planes, kernel_size=(1 + temp_conv * 2, 1, 1), stride=(temp_stride, 1, 1),
                               padding=(temp_conv, 0, 0), bias=False)
        self.bn1 = nn.BatchNorm3d(planes)
        self.conv2 = nn.Conv3d(planes, planes, kernel_size=(1, 3, 3), stride=(1, stride, stride), padding=(0, 1, 1),
                               bias=False)
        self.bn2 = nn.BatchNorm3d(planes)
        self.conv3 = nn.Conv3d(planes, planes * 4, kernel_size=1, stride=1, padding=0, bias=False)
        self.bn3 = nn.BatchNorm3d(planes * 4)
        self.relu = nn.ReLU(inplace=True)
        self.downsample = downsample
        self.stride = stride

        # 输出通道数是输入通道数的4倍
        outplanes = planes * 4
        # self.nl = NonLocalBlock(outplanes, outplanes, outplanes // 64) if use_nl else None # 全局注意力模块
        # self.nl = CrissCrossAttention3D(outplanes) # 交叉注意力模块
        self.nl = ST3DCCBlock(outplanes, outplanes) # 另外的ST3DCCBlock模块

    def forward(self, x):
        residual = x

        out = self.conv1(x)
        out = self.bn1(out)
        out = self.relu(out)

        out = self.conv2(out)
        out = self.bn2(out)
        out = self.relu(out)

        out = self.conv3(out)
        out = self.bn3(out)

        if self.downsample is not None:
            residual = self.downsample(x)

        out += residual
        out = self.relu(out)

        if self.nl is not None:
            out = self.nl(out)
            # for i in range(2):
            #     # (B,C,T,N,N)
            # out = out.permute(0, 1, 3, 4, 2)
            # (B,C,N,N,T)
            # out = self.nl(out)
            # bchwd -> bcdhw
            # out = out.permute(0, 1, 4, 2, 3)
        return out


class I3Res50(nn.Module):

    def __init__(self, block=Bottleneck, input_dim=1, down=False, layers=[1, 1, 1, 1], num_nodes=400, use_nl=False):
        self.inplanes = 16
        super(I3Res50, self).__init__()
        self.conv1 = nn.Conv3d(input_dim, 16, kernel_size=(5, 7, 7), stride=(2, 1, 1), padding=(2, 3, 3), bias=False)
        self.bn1 = nn.BatchNorm3d(16)
        self.relu = nn.ReLU(inplace=True)
        self.maxpool1 = nn.MaxPool3d(kernel_size=(2, 3, 3), stride=(2, 2, 2), padding=(0, 0, 0))
        self.maxpool2 = nn.MaxPool3d(kernel_size=(2, 1, 1), stride=(2, 1, 1), padding=(0, 0, 0))

        nonlocal_mod = 2 if use_nl else 1000
        self.layer1 = self._make_layer(block, 16, layers[0], stride=1, temp_conv=[1, 1, 1], temp_stride=[1, 1, 1])
        self.layer2 = self._make_layer(block, 32, layers[1], stride=1, temp_conv=[1, 0, 1, 0],
                                       temp_stride=[1, 1, 1, 1], nonlocal_mod=nonlocal_mod)
        self.layer3 = self._make_layer(block, 64, layers[2], stride=1, temp_conv=[1, 0, 1, 0, 1, 0],
                                       temp_stride=[1, 1, 1, 1, 1, 1], nonlocal_mod=nonlocal_mod)
        self.layer4 = self._make_layer(block, 128, layers[3], stride=1, temp_conv=[0, 1, 0], temp_stride=[1, 1, 1])
        # self.avgpool = nn.AdaptiveAvgPool3d((1, 1, 1))
        # self.fc = nn.Linear(512 * block.expansion, num_classes)
        # self.drop = nn.Dropout(0.5)
        self.num_nodes = num_nodes
        self.down = down
        # for m in self.modules():
        #     if isinstance(m, nn.Conv3d):
        #         m.weight = nn.init.kaiming_normal_(m.weight, mode='fan_out')
        #     elif isinstance(m, nn.BatchNorm3d):
        #         m.weight.data.fill_(1)
        #         m.bias.data.zero_()

    def _make_layer(self, block, planes, blocks, stride, temp_conv, temp_stride, nonlocal_mod=1000):
        downsample = None
        if stride != 1 or self.inplanes != planes * block.expansion or temp_stride[0] != 1:
            downsample = nn.Sequential(
                nn.Conv3d(self.inplanes, planes * block.expansion, kernel_size=(1, 1, 1),
                          stride=(temp_stride[0], stride, stride), padding=(0, 0, 0), bias=False),
                nn.BatchNorm3d(planes * block.expansion)
            )

        layers = []
        layers.append(block(self.inplanes, planes, stride, downsample, temp_conv[0], temp_stride[0], False))
        self.inplanes = planes * block.expansion
        for i in range(1, blocks):
            layers.append(block(self.inplanes, planes, 1, None, temp_conv[i], temp_stride[i],
                                i % nonlocal_mod == nonlocal_mod - 1))

        return nn.Sequential(*layers)

    def forward(self, x):
        x = self.conv1(x)
        x = self.bn1(x)
        x = self.relu(x)
        if self.down:
            x = self.maxpool2(x)

        x = self.layer1(x)
        if self.down:
            x = self.maxpool2(x)
        x = self.layer2(x)
        x = self.layer3(x)
        x = self.layer4(x)

        # x = self.avgpool(x)
        # x = self.drop(x)

        x = x.contiguous().view(x.shape[0], -1, self.num_nodes, self.num_nodes)
        # x = self.fc(x)
        return x
