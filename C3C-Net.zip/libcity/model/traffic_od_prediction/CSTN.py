import torch
import torch.nn as nn

from libcity.model import loss
from libcity.model.abstract_traffic_state_model import AbstractTrafficStateModel


class ConvLSTMCell(nn.Module):
    def __init__(self, input_dim, hidden_dim, kernel_size, bias):
        super(ConvLSTMCell, self).__init__()
        self.input_dim = input_dim
        self.hidden_dim = hidden_dim
        self.kernel_size = kernel_size
        self.padding = kernel_size[0] // 2, kernel_size[1] // 2
        self.bias = bias
        self.conv = nn.Conv2d(in_channels=self.input_dim + self.hidden_dim,
                              out_channels=4 * self.hidden_dim,
                              kernel_size=self.kernel_size,
                              padding=self.padding,
                              bias=self.bias)

    def forward(self, input_tensor, cur_state):
        h_cur, c_cur = cur_state
        combined = torch.cat([input_tensor, h_cur], dim=1)
        combined_conv = self.conv(combined)
        cc_i, cc_f, cc_o, cc_g = torch.split(combined_conv, self.hidden_dim, dim=1)
        i = torch.sigmoid(cc_i)
        f = torch.sigmoid(cc_f)
        o = torch.sigmoid(cc_o)
        g = torch.tanh(cc_g)
        c_next = f * c_cur + i * g
        h_next = o * torch.tanh(c_next)
        return h_next, c_next

    def init_hidden(self, batch_size, image_size):
        height, width = image_size
        return (torch.zeros(batch_size, self.hidden_dim, height, width, device=self.conv.weight.device),
                torch.zeros(batch_size, self.hidden_dim, height, width, device=self.conv.weight.device))


class ConvLSTM(nn.Module):
    def __init__(self, input_dim, hidden_dim, kernel_size, num_layers,
                 batch_first=False, bias=True, return_all_layers=False):
        super(ConvLSTM, self).__init__()
        kernel_size = [kernel_size] * num_layers if not isinstance(kernel_size, list) else kernel_size
        hidden_dim = [hidden_dim] * num_layers if not isinstance(hidden_dim, list) else hidden_dim
        self.input_dim = input_dim
        self.hidden_dim = hidden_dim
        self.kernel_size = kernel_size
        self.num_layers = num_layers
        self.batch_first = batch_first
        self.bias = bias
        self.return_all_layers = return_all_layers
        self.cell_list = nn.ModuleList([
            ConvLSTMCell(input_dim=self.input_dim if i == 0 else self.hidden_dim[i - 1],
                         hidden_dim=self.hidden_dim[i],
                         kernel_size=self.kernel_size[i],
                         bias=self.bias) for i in range(self.num_layers)
        ])

    def forward(self, input_tensor, hidden_state=None):
        if not self.batch_first:
            input_tensor = input_tensor.permute(1, 0, 2, 3, 4)
        b, _, _, h, w = input_tensor.size()
        hidden_state = hidden_state or self._init_hidden(b, (h, w))
        cur_layer_input = input_tensor
        layer_output_list, last_state_list = [], []
        for layer_idx in range(self.num_layers):
            h, c = hidden_state[layer_idx]
            output_inner = []
            for t in range(input_tensor.size(1)):
                h, c = self.cell_list[layer_idx](cur_layer_input[:, t, :, :, :], [h, c])
                output_inner.append(h)
            layer_output = torch.stack(output_inner, dim=1)
            cur_layer_input = layer_output
            layer_output_list.append(layer_output)
            last_state_list.append([h, c])
        if not self.return_all_layers:
            layer_output_list, last_state_list = layer_output_list[-1:], last_state_list[-1:]
        return layer_output_list, last_state_list

    def _init_hidden(self, batch_size, image_size):
        return [self.cell_list[i].init_hidden(batch_size, image_size) for i in range(self.num_layers)]


class CNN(nn.Module):
    def __init__(self, height, width, n_layers):
        super(CNN, self).__init__()
        self.conv = nn.ModuleList([nn.Conv2d(1, 16, 3, padding=1)])
        for _ in range(1, n_layers):
            self.conv.append(nn.ReLU())
            self.conv.append(nn.Conv2d(16, 16, 3, padding=1))
        self.relu = nn.ReLU()
        self.embed = nn.Sequential(
            nn.Conv2d(height * width * 16, 32, 1),
            nn.ReLU()
        )

    def forward(self, x):
        _x = x
        x = self.conv[0](x)
        for i in range(1, len(self.conv) // 2 + 1):
            x += _x
            x = self.conv[2 * i - 1](x)
            _x = x
            x = self.conv[2 * i](x)
        x += _x
        x = self.relu(x)
        b, c, h, w = x.shape
        x = x.reshape(b, h * w * c, h, w)
        x = self.embed(x)
        return x


class LSC(nn.Module):
    def __init__(self, height, width, n_layers):
        super(LSC, self).__init__()
        self.CNN = CNN(height, width, n_layers)

    def forward(self, x):
        return self.CNN(x)


class TEC(nn.Module):
    def __init__(self, c_lt):
        super(TEC, self).__init__()
        self.ConvLSTM = ConvLSTM(40, 32, (3, 3), 1, batch_first=True)
        self.conv = nn.Sequential(nn.Conv2d(32, c_lt, 1), nn.ReLU())

    def forward(self, x):
        x, _ = self.ConvLSTM(x)
        x = self.conv(x[0][:, -1])
        return x


class GCC(nn.Module):
    def __init__(self):
        super(GCC, self).__init__()
        self.Softmax = nn.Softmax(dim=0)

    def forward(self, x):
        b, c, h, w = x.shape
        _x = x.reshape(b, c, h * w)
        s = torch.bmm(_x.transpose(1, 2), _x)
        s = self.Softmax(s)
        x = torch.bmm(_x, s).reshape(b, c, h, w)
        return torch.cat([x, x.reshape(b, c, h, w)], dim=1)


class CSTN(AbstractTrafficStateModel):
    def __init__(self, config, data_feature):
        super().__init__(config, data_feature)
        self.device = config.get('device', torch.device('cpu'))
        self.batch_size = config.get('batch_size')
        self.output_dim = config.get('output_dim')
        self.input_window = config.get('input_window', 1)
        self.output_window = config.get('output_window', 1)
        self._scaler = data_feature.get('scaler')
        self.height = data_feature.get('num_nodes')  # N 作为 height
        self.width = data_feature.get('num_nodes')   # N 作为 width
        self.n_layers = config.get('n_layers', 3)
        self.c_lt = config.get('c_lt', 75)
        self.LSC = LSC(self.height, self.width, self.n_layers)
        self.TEC = TEC(self.c_lt)
        self.GCC = GCC()
        self.OUT = nn.Sequential(
            nn.Conv2d(2 * self.c_lt, self.height * self.width, 1),
            nn.ReLU(),
            nn.Tanh()
        )

    def forward(self, batch):
        x = batch['X'][..., 0]
        x = x.reshape(-1, 1, self.height, self.width)
        x = self.LSC(x)
        x = x.reshape(self.batch_size, self.input_window, 32, self.height, self.width)
        x = self.TEC(x)
        x = self.GCC(x)
        x = self.OUT(x)
        x = x.reshape(self.batch_size, 1, self.height, self.width, self.height, self.width, 1)
        return x

    def calculate_loss(self, batch):
        y_true = batch['y']
        y_pred = self.predict(batch)
        y_true = self._scaler.inverse_transform(y_true[..., :self.output_dim])
        y_pred = self._scaler.inverse_transform(y_pred[..., :self.output_dim])
        return loss.masked_mse_torch(y_pred, y_true)

    def predict(self, batch):
        x = batch['X']
        y = batch['y']
        y_preds = []
        x_ = x.clone()
        for i in range(self.output_window):
            batch_tmp = {'X': x_}
            y_ = self.forward(batch_tmp)
            y_preds.append(y_.clone())
            if y_.shape[-1] < x_.shape[-1]:
                y_ = torch.cat([y_, y[:, i:i+1, :, :, self.output_dim:]], dim=-1)
            x_ = torch.cat([x_[:, 1:], y_], dim=1)
        return torch.cat(y_preds, dim=1)
