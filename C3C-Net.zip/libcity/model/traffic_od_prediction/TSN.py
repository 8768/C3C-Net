import torch
import torch.nn as nn
import torch.nn.functional as F
from .backbone import I3Res50, Bottleneck, ConvBNRelu, ResNet18, FeatureNet
from collections import OrderedDict
from logging import getLogger

from libcity.model.abstract_traffic_state_model import AbstractTrafficStateModel
from libcity.model import loss


class CNN3D(nn.Module):
    def __init__(self, height, width, input_window, h_num):
        super(CNN3D, self).__init__()
        self.height = height
        self.width = width
        self.h_num = h_num
        self.input_window = input_window
        # self.MLP = MLP()
        self.input = nn.Conv3d(in_channels=self.height * self.width, out_channels=32, kernel_size=1)
        self.relu = nn.ReLU()
        self.out = nn.Conv3d(in_channels=32, out_channels=h_num, kernel_size=3, padding=1)

    def forward(self, x):
        # (B,T,N,N)
        x = x.reshape((-1, self.height * self.width, self.input_window, self.height, self.width))
        # (B,N,T,H,W)

        # w = self.MLP(w)
        # # w : (B, T, 8)
        # w = w.repeat(1, 1, self.height * self.width)
        # w = w.reshape((self.batch_size, 8, self.input_window, self.height, self.width))
        # # w : (B, 8, T, H, W)
        # x = torch.cat([x, w], dim=1)

        x = self.input(x)
        x = self.relu(x)
        x = self.out(x)
        x = self.relu(x)
        # (B,h_num,T,H,W)
        x = x.reshape((-1, self.h_num, self.input_window, self.height * self.width)).unsqueeze(-1)
        # (B,h_num,T,N,1)
        return x


class ODEmbed(nn.Module):
    def __init__(self, height, width, input_window, h_num):
        super(ODEmbed, self).__init__()
        self.height = height
        self.width = width
        self.h_num = h_num
        self.input_window = input_window
        self.O_CNN3D = CNN3D(self.height, self.width, self.input_window, self.h_num)
        self.D_CNN3D = CNN3D(self.height, self.width, self.input_window, self.h_num)
        self.conv_o = nn.Conv3d(in_channels=self.h_num, out_channels=8, kernel_size=3, padding=1)
        self.conv_d = nn.Conv3d(in_channels=self.h_num, out_channels=8, kernel_size=3, padding=1)

    def forward(self, x):
        # (B, T, N, N)
        xo = self.O_CNN3D(x)
        # xo:(B,h,T,N,1)
        xo_t = xo.permute(0, 1, 2, 4, 3)
        xd = x.permute(0, 1, 3, 2)
        xd = self.D_CNN3D(xd)
        # xd:(B,h,T,N,1)

        xo = torch.matmul(xo, xd.permute(0, 1, 2, 4, 3))
        # xo (B, h, T, N, N)
        xd = torch.matmul(xd, xo_t)

        # xo = torch.cat([xo, xod], dim=1)
        xo = self.conv_o(xo)
        # xo (B, 16, T, N, N)
        # xd = torch.cat([xd, xod], dim=1)
        xd = self.conv_d(xd)

        return F.relu(torch.cat([xo, xd], dim=1))


class ODEmbed_1(nn.Module):
    def __init__(self, height, width, input_window, h_num):
        super(ODEmbed_1, self).__init__()
        self.height = height
        self.width = width
        self.h_num = h_num
        self.input_window = input_window
        self.o_cnn = nn.Conv3d(in_channels=1, out_channels=16, kernel_size=3, padding=1)
        self.d_cnn = nn.Conv3d(in_channels=1, out_channels=16, kernel_size=3, padding=1)
        self.poi_embedding = nn.Conv3d(in_channels=14, out_channels=1, kernel_size=1)
        self.max_pool = nn.MaxPool3d(kernel_size=(2, 2, 2))

    def forward(self, x, xod, p):
        # (B, T, N, N)
        xo = x.reshape((-1, 1, self.input_window, self.height, self.width))
        xd = x.permute(0, 1, 3, 2).reshape((-1, 1, self.input_window, self.height, self.width))
        # poi embedding
        if len(p.shape) > 1:
            p = p.repeat(self.height * self.width, 1, self.input_window, 1).reshape(
                (xo.shape[0], -1, self.input_window, self.height, self.width))
            p = self.poi_embedding(p)
            xo = xo + p
            xd = xd + p
        xo = self.o_cnn(xo)
        xo = xo.reshape((-1, 16, self.input_window, self.height * self.width, self.height * self.width))
        # (B*N,16, T, H, W)
        xd = self.d_cnn(xd)
        xd = xd.reshape((-1, 16, self.input_window, self.height * self.width, self.height * self.width))
        xo = self.max_pool(xo)
        xd = self.max_pool(xd)

        return F.relu(torch.cat([xo, xd], dim=1) + xod)
    
class CrossAttention(nn.Module):
    def __init__(self):
        super(CrossAttention, self).__init__()
        self.Softmax = nn.Softmax(dim=-1)
        self.tanh = nn.Sigmoid()

    def forward(self, q, k, v):
        heatmap = torch.matmul(q, k.transpose(-1, -2))
        heatmap = heatmap * (100 ** -.5)
        heatmap = F.softmax(heatmap, dim=-1)
        # heatmap = self.dropout(heatmap)
        # s: (B, H * W, H * W)
        v = torch.matmul(heatmap, v)
        # v = self.tanh(v)
        return v

class TSN(AbstractTrafficStateModel):
    def __init__(self, config, data_feature):
        super().__init__(config, data_feature)
        self.num_nodes = self.data_feature.get('num_nodes')
        self._scaler = self.data_feature.get('scaler')
        self.output_dim = config.get('output_dim')
        self.device = config.get('device', torch.device('cpu'))
        self.input_window = config.get('input_window', 1)
        self.output_window = config.get('output_window', 1)

        self.p_interval = config.get('p_interval', 1)
        self.embed_dim = config.get('embed_dim')
        self.batch_size = config.get('batch_size')
        self.loss_p0 = config.get('loss_p0', 0.5)
        self.loss_p1 = config.get('loss_p1', 0.25)
        self.loss_p2 = config.get('loss_p2', 0.25)
        self.height = data_feature.get('len_row', 15)
        self.width = data_feature.get('len_column', 5)
        self.nb_residual_unit = config.get('nb_residual_unit', 4)
        self.bn = config.get('bn', False)
        self.h_num = config.get('h_num', 16)
        self.rich_t = config.get('rich_t', 6)

        dis_mx = self.data_feature.get('adj_mx')
        self.weather_embedding = nn.Conv3d(in_channels=8, out_channels=1, kernel_size=1)
        # self.long = I3Res50(Bottleneck, down=True, num_nodes=self.num_nodes, use_nl=True)
        # self.rich = I3Res50(Bottleneck, input_dim=16, num_nodes=self.num_nodes, use_nl=True)
        self.long = ResNet18(self.height, self.width)
        self.rich = ResNet18(self.height, self.width)
        # self.conv3d_1 = nn.Sequential(nn.Conv3d(in_channels=1, out_channels=16, kernel_size=3, padding=1),
        #                               nn.ReLU(inplace=False),
        #                               # nn.MaxPool3d(kernel_size=(1,2,2)),
        #                               nn.Conv3d(in_channels=16, out_channels=32, kernel_size=3, padding=1),
        #                               nn.ReLU(inplace=False),
        #                               nn.MaxPool3d(kernel_size=(2,2,2))
        #                               )
        self.od_embedding = ODEmbed(self.height, self.width, self.rich_t, self.h_num)
        # self.ST_Blocks = ST3DCCBlock(32, 32)
        # self.ST_Blocks_1 = ST3DCCBlock(32, 32)
        # self.embed = nn.Sequential(nn.Conv2d(in_channels=self.input_window*128, out_channels=128, kernel_size=1),
        #                            nn.ReLU(inplace=False),
        #                            nn.Conv2d(in_channels=128, out_channels=64, kernel_size=3,padding=1),
        #                            nn.ReLU(inplace=False))
        # self.spablock = ResUnits(ResidualUnit, nb_filter=64, repetations=self.nb_residual_unit, bn=self.bn)
        self.output = nn.Sequential(
            nn.Conv2d(in_channels=self.input_window * 32, out_channels=128, kernel_size=1),
            nn.ReLU(inplace=False),
            nn.Conv2d(in_channels=128, out_channels=64, kernel_size=1),
            nn.Sigmoid(),
            nn.Conv2d(64, self.output_dim, kernel_size=1))

        for m in self.modules():
            if isinstance(m, nn.Conv3d):
                m.weight = nn.init.kaiming_normal_(m.weight, mode='fan_out')
            elif isinstance(m, nn.BatchNorm3d):
                m.weight.data.fill_(1)
                m.bias.data.zero_()

    def forward(self, batch):
        x = batch['X'].squeeze(dim=-1)
        # (B, T, N, N)
        p = batch['P']

        xod = x[:, -self.rich_t * 4:, ...].unsqueeze(1)
        long = self.long(xod)
        # rich = self.od_embedding(x[:,-self.rich_t:,...])
        # rich = self.rich(rich)
        # # (B, C, T, N, N)
        #
        # x = 0.6 * long + 0.4*rich
        # x = torch.cat([rich, short], dim=1)
        # out = xod.reshape((x.shape[0], -1, self.num_nodes, self.num_nodes))
        # out = self.output(xod)
        # w = batch['W']
        # # w : (B, T, F)
        # w = w.permute(0, 2, 1).unsqueeze(-1).unsqueeze(-1).repeat(1, 1, 1, self.num_nodes, self.num_nodes)
        # w = self.weather_embedding(w)  # B,1,T+1,N,N
        # xod = xod + w[:,:,:self.input_window,...]

        # xod = self.conv3d_1(xod)
        # (B, 32, T, N, N)

        # x = self.ST_Blocks(xod)
        # x = self.ST_Blocks_1(x)
        # x = x.reshape((x.shape[0], -1, self.num_nodes, self.num_nodes))
        # x = self.embed(x)
        # x = self.spablock(x)
        # out = self.output(x)
        out = long.unsqueeze(dim=-1)
        out = out.unsqueeze(dim=1)
        # x_ge_embed = self.GCN(x, self.geo_adj[:x.shape[0], ...])
        # # (B, T, N, E)
        #
        # x_se_embed = self.GCN(x, self.semantic_adj)
        #
        # # (B, T, N, E)
        # x_embed = torch.cat([x_ge_embed, x_se_embed], dim=3)
        # # (B, T, N, 2E)
        # x_embed = x_embed.permute(1, 0, 2, 3)
        # # (T, B, N, 2E)
        # x_embed = x_embed.reshape((self.input_window, -1, 2 * self.embed_dim))
        # # (T,
        # # _, (h, _) = self.LSTM(x_embed)
        # # x_embed_pred = h[0].reshape((self.batch_size, -1, 2 * self.embed_dim))
        # x_embed_pred = self.LSTM(x_embed).reshape((x.shape[0], -1, 2 * self.embed_dim))
        # # (B, N, 2E)
        #
        # out = self.mutiLearning(x_embed_pred)

        return out

    def calculate_loss(self, batch):
        y_true = batch['y']  # (B, TO, N, N, 1)
        # y_in_true = torch.sum(y_true, dim=-2, keepdim=True)  # (B, TO, N, 1)
        # y_out_true = torch.sum(y_true.permute(0, 1, 3, 2, 4), dim=-2, keepdim=True)  # (B, TO, N, 1)
        # y_pred, y_in, y_out = self.predict(batch)

        y_pred = self.predict(batch)

        y_true = self._scaler.inverse_transform(y_true[..., :self.output_dim])
        # y_in_true = self._scaler.inverse_transform(y_in_true[..., :self.output_dim])
        # y_out_true = self._scaler.inverse_transform(y_out_true[..., :self.output_dim])

        y_pred = self._scaler.inverse_transform(y_pred[..., :self.output_dim])
        # y_in = self._scaler.inverse_transform(y_in[..., :self.output_dim])
        # y_out = self._scaler.inverse_transform(y_out[..., :self.output_dim])

        loss_pred = loss.masked_mse_torch(y_pred, y_true)
        # loss_in = loss.masked_mse_torch(y_in, y_in_true)
        # loss_out = loss.masked_mse_torch(y_out, y_out_true)
        # return self.loss_p0 * loss_pred + self.loss_p1 * loss_in + self.loss_p2 * loss_out
        return loss_pred

    def predict(self, batch):
        x = batch['X']  # (B, T, N, N, 1)
        # self.semantic_adj = generate_semantic_adj(x.squeeze(dim=-1), self.device)
        assert x.shape[-1] == 1 or print("The feature_dim must be 1")
        y_pred = []
        y_in_pred = []
        y_out_pred = []
        x_ = x.clone()
        for i in range(self.output_window):
            batch_tmp = {'X': x_}
            # y_, y_in_, y_out_ = self.forward(batch_tmp)  # (B, 1, N, N, 1)
            y_ = self.forward(batch)
            y_pred.append(y_.clone())
            # y_in_pred.append(y_in_.clone())
            # y_out_pred.append(y_out_.clone())

            x_ = torch.cat([x_[:, 1:, :, :, :], y_], dim=1)

        y_pred = torch.cat(y_pred, dim=1)  # (B, TO, N, N, 1)
        # y_in_pred = torch.cat(y_in_pred, dim=1)  # (B, TO, N, 1)
        # y_out_pred = torch.cat(y_out_pred, dim=1)  # (B, TO, N, 1)
        # return y_pred, y_in_pred, y_out_pred
        return y_pred


class Encoder(nn.Module):
    def __init__(self):
        super(Encoder, self).__init__()
        self.sim = FeatureNet()
        self.cor = FeatureNet()
        # self.ext = FeatureNet()
        # self.ext_ca = CrossAttention()
        self.cor_ca = CrossAttention()
        self.sim_ca = CrossAttention()

    def forward(self, sim, cor, ext):
        B, C, T, H, W = sim.shape

        sim = sim.reshape([B, C, T, -1]).unsqueeze(3)
        sim = self.sim_ca(sim, cor, cor)
        cor = self.cor_ca(cor, sim, sim)
        # ext = self.ext_ca(ext, ext, ext)
        sim = sim.reshape([B, C, T, H, W])

        sim = self.sim(sim)
        cor = self.cor(cor)
        # ext = self.ext(ext)
        return sim, cor, ext

class MOMO(AbstractTrafficStateModel):
    def __init__(self, config, data_feature):
        super().__init__(config, data_feature)
        self.num_nodes = self.data_feature.get('num_nodes')
        self._scaler = self.data_feature.get('scaler')
        self.output_dim = config.get('output_dim')
        self.device = config.get('device', torch.device('cpu'))
        self.input_window = config.get('input_window', 1)
        self.output_window = config.get('output_window', 1)

        self.p_interval = config.get('p_interval', 1)
        self.feature_dim = config.get('feature_dim')
        self.batch_size = config.get('batch_size')
        self.loss_p0 = config.get('loss_p0', 0.5)
        self.loss_p1 = config.get('loss_p1', 0.25)
        self.loss_p2 = config.get('loss_p2', 0.25)
        self.height = data_feature.get('len_row', 15)
        self.width = data_feature.get('len_column', 5)
        self.nb_residual_unit = config.get('nb_residual_unit', 4)
        self.bn = config.get('bn', False)
        self.h_num = config.get('h_num', 16)
        self.rich_t = config.get('rich_t', 6)
        self.sim_position = nn.Parameter(torch.randn(self.height, self.width).to(self.device),
                                         requires_grad=True)
        self.cor_position = nn.Parameter(torch.randn(self.num_nodes, self.num_nodes).to(self.device),requires_grad=True)
        # self.position_embedding = nn.Embedding(self.num_nodes, self.num_nodes)
        self.similarity = ConvBNRelu(in_channels=2, out_channels=16, stride=(1, 1, 1), kernel_size=3, padding=1)
        self.correlation = ConvBNRelu(in_channels=1, out_channels=8, stride=(1, 1, 1), kernel_size=3, padding=1)
        self.external = ConvBNRelu(in_channels=self.feature_dim, out_channels=8, stride=(1, 1, 1), kernel_size=3, padding=1)
        self.layer_stack = nn.ModuleList([Encoder() for _ in range(4)])
        self.att = CrossAttention()
        self.fc = nn.Sequential(
            nn.Conv2d(in_channels=self.input_window * 16, out_channels=self.num_nodes, kernel_size=1),
            nn.ReLU(inplace=False),
            nn.Tanh()
            # nn.Conv2d(in_channels=16, out_channels=1, kernel_size=1),
            # nn.ReLU()
            )


        # dis_mx = self.data_feature.get('adj_mx')
        # self.external = ResNet18(self.height, self.width, in_channels=self.feature_dim, scale=1, mode='sim')
        # self.correlation = ResNet18(self.height, self.width, scale=1, mode='sim')
        # self.similarity = ResNet18(self.height, self.width, in_channels=2 * self.num_nodes, scale=1)
        # self.cor_fc = nn.Linear(self.num_nodes * self.num_nodes, self.num_nodes)
        # self.sim_fc = nn.Linear(self.num_nodes, self.num_nodes)
        # self.exter_fc = nn.Linear(self.num_nodes * self.num_nodes, self.num_nodes)
        # self.cor_ca = CrossAttention()
        # self.sim_ca = CrossAttention()

        # self.conv3d_1 = nn.Sequential(nn.Conv3d(in_channels=1, out_channels=16, kernel_size=3, padding=1),
        #                               nn.ReLU(inplace=False),
        #                               # nn.MaxPool3d(kernel_size=(1,2,2)),
        #                               nn.Conv3d(in_channels=16, out_channels=32, kernel_size=3, padding=1),
        #                               nn.ReLU(inplace=False),
        #                               nn.MaxPool3d(kernel_size=(2,2,2))
        #                               )
        # self.od_embedding = ODEmbed(self.height, self.width, self.rich_t, self.h_num)
        # self.ST_Blocks = ST3DCCBlock(32, 32)
        # self.ST_Blocks_1 = ST3DCCBlock(32, 32)
        # self.embed = nn.Sequential(nn.Conv2d(in_channels=self.input_window*128, out_channels=128, kernel_size=1),
        #                            nn.ReLU(inplace=False),
        #                            nn.Conv2d(in_channels=128, out_channels=64, kernel_size=3,padding=1),
        #                            nn.ReLU(inplace=False))
        # self.spablock = ResUnits(ResidualUnit, nb_filter=64, repetations=self.nb_residual_unit, bn=self.bn)
        # self.output = nn.Sequential(
        #     nn.Conv2d(in_channels=self.input_window * 32, out_channels=128, kernel_size=1),
        #     nn.ReLU(inplace=False),
        #     nn.Conv2d(in_channels=128, out_channels=64, kernel_size=1),
        #     nn.Sigmoid(),
        #     nn.Conv2d(64, self.output_dim, kernel_size=1))
        for m in self.modules():
            if isinstance(m, nn.Conv3d):
                m.weight = nn.init.kaiming_normal_(m.weight, mode='fan_out')
            elif isinstance(m, nn.BatchNorm3d):
                m.weight.data.fill_(1)
                m.bias.data.zero_()

    def forward(self, batch):
        x = batch['X'][..., 0]#.squeeze(dim=-1)
        # (B, T, N, N)
        B, T, N, _ = x.shape
        # external

        if N < 100:
            # nyc taxi feature dim 37
            ext = batch['W']
            ext = ext.repeat(self.num_nodes, self.num_nodes, 1, 1, 1).permute(2, 4, 3, 0, 1)
        else:
            # cd taxi feature dim 45
            # 暂时不用POI
            ext = batch['X'][..., 1:]  # 只用外部特征
            ext = ext.permute(0, 4, 1, 2, 3)  # 只对ext做permute

            # 用POI
            # p = batch['P']#[..., :1]
            # ext = batch['X'][..., 1:]
            # ext = torch.cat([ext, p], dim=-1).permute(0, 4, 1, 2, 3)
        ext = self.external(ext)

        # similarity
        # xo = x.reshape([-1, self.input_window, self.num_nodes, self.height, self.width])
        # xd = x.permute(0, 1, 3, 2).reshape([-1, self.input_window, self.num_nodes, self.height, self.width])
        # sim = torch.cat([xo, xd], dim=2).permute(0, 2, 1, 3, 4)
        # sim = self.similarity(sim)
        # update sum
        xo = torch.sum(x, dim=3, keepdim=True).permute(0, 1, 3, 2)
        xd = torch.sum(x, dim=2, keepdim=True)
        sim = torch.cat([xo, xd], dim=2).permute(0, 2, 1, 3)
        # infow and outflow
        sim = sim.reshape([-1, 2, self.input_window, self.height, self.width])
        # [b,2,t,h,w]
        sim = sim + self.sim_position.repeat(B, 2, T, 1, 1)
        # sim = torch.cat([sim, ext], dim=1)
        sim = self.similarity(sim)

        # correlation
        # position = torch.arange(100,device=x.device)
        # position = self.position_embedding(position)
        # position = position.repeat(B, T, 1, 1)

        x = x + self.cor_position.repeat(B, T, 1, 1)
        x = x.unsqueeze(1)
        cor = self.correlation(x)
        cor = torch.cat([cor, ext], dim=1)


        #-------new version------
        for enc_layer in self.layer_stack:
            sim, cor, ext = enc_layer(sim, cor, ext)
        B, C, T, H, W = sim.shape
        sim = sim.reshape([B, C, T, -1]).unsqueeze(3)
        # out = self.att(cor, sim, sim)
        # out = out.reshape([B, -1, self.num_nodes, self.num_nodes])
        # out = self.fc(out)

        out = self.att(sim, cor, cor)
        out = out.reshape([B, -1, self.height, self.width])
        out = self.fc(out)
        out = out.reshape([B, -1, self.num_nodes]).unsqueeze(dim=1)
        # -------new version------
        # rich = self.od_embedding(x[:,-self.rich_t:,...])
        # rich = self.rich(rich)
        # # (B, C, T, N, N)
        #
        # x = 0.6 * long + 0.4*rich
        # x = torch.cat([rich, short], dim=1)
        # out = xod.reshape((x.shape[0], -1, self.num_nodes, self.num_nodes))
        # out = self.output(xod)
        # w = batch['W']
        # # w : (B, T, F)
        # w = w.permute(0, 2, 1).unsqueeze(-1).unsqueeze(-1).repeat(1, 1, 1, self.num_nodes, self.num_nodes)
        # w = self.weather_embedding(w)  # B,1,T+1,N,N
        # xod = xod + w[:,:,:self.input_window,...]

        # xod = self.conv3d_1(xod)
        # (B, 32, T, N, N)

        # x = self.ST_Blocks(xod)
        # x = self.ST_Blocks_1(x)
        # x = x.reshape((x.shape[0], -1, self.num_nodes, self.num_nodes))
        # x = self.embed(x)
        # x = self.spablock(x)
        # out = self.output(x)
        # sim = self.sim_fc(sim)
        # cor = self.cor_fc(cor)
        # ext = self.exter_fc(ext)

        # two view cross attention
        # cor = self.cor_ca(ext,cor,cor)
        # sim = self.sim_ca(ext,sim,sim)
        # out = cor + sim

        # one view cross attention
        # out = self.cor_ca(ext,sim,cor)

        out = out.unsqueeze(dim=-1)
        # out = out.unsqueeze(dim=1)

        return out

    def calculate_loss(self, batch):
        y_true = batch['y']  # (B, TO, N, N, 1)
        # y_in_true = torch.sum(y_true, dim=-2, keepdim=True)  # (B, TO, N, 1)
        # y_out_true = torch.sum(y_true.permute(0, 1, 3, 2, 4), dim=-2, keepdim=True)  # (B, TO, N, 1)
        # y_pred, y_in, y_out = self.predict(batch)

        y_pred = self.predict(batch)

        y_true = self._scaler.inverse_transform(y_true[..., :self.output_dim])
        # y_in_true = self._scaler.inverse_transform(y_in_true[..., :self.output_dim])
        # y_out_true = self._scaler.inverse_transform(y_out_true[..., :self.output_dim])

        y_pred = self._scaler.inverse_transform(y_pred[..., :self.output_dim])
        # y_in = self._scaler.inverse_transform(y_in[..., :self.output_dim])
        # y_out = self._scaler.inverse_transform(y_out[..., :self.output_dim])

        loss_pred = loss.masked_mse_torch(y_pred, y_true)
        # loss_in = loss.masked_mse_torch(y_in, y_in_true)
        # loss_out = loss.masked_mse_torch(y_out, y_out_true)
        # return self.loss_p0 * loss_pred + self.loss_p1 * loss_in + self.loss_p2 * loss_out
        return loss_pred

    def predict(self, batch):
        x = batch['X']  # (B, T, N, N, 1)
        # self.semantic_adj = generate_semantic_adj(x.squeeze(dim=-1), self.device)
        # assert x.shape[-1] == 1 or print("The feature_dim must be 1")
        w = batch['W']
        y = batch['y']
        p = batch['P']
        y_pred = []
        x_ = x.clone()
        for i in range(self.output_window):
            # batch_tmp = {'X': x_}
            batch_tmp = {'X': x_, 'W': w[:, i:(i + self.input_window), ...], 'P': p}
            y_ = self.forward(batch_tmp)
            y_pred.append(y_.clone())
            if y_.shape[-1] < x_.shape[-1]:  # output_dim < feature_dim
                y_ = torch.cat([y_, y[:, i:i + 1, :, :, self.output_dim:]], dim=-1)

            x_ = torch.cat([x_[:, 1:, :, :, :], y_], dim=1)

        y_pred = torch.cat(y_pred, dim=1)  # (B, TO, N, N, 1)
        # y_in_pred = torch.cat(y_in_pred, dim=1)  # (B, TO, N, 1)
        # y_out_pred = torch.cat(y_out_pred, dim=1)  # (B, TO, N, 1)
        # return y_pred, y_in_pred, y_out_pred
        return y_pred


